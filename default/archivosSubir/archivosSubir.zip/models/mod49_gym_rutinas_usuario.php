<?php

	class Mod49GymRutinasUsuario extends ActiveRecord
{

	

	public function getTodas(){

        return $this->find();

    }

	

}

?>