<?php

	class Mod49GymPromocionesUsuario extends ActiveRecord
{

	

	public function getTodas(){

        return $this->find();

    }

	

}

?>