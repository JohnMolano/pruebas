<?php

	class Mod49GymBuzon extends ActiveRecord

{

	

	public function getTodas(){

        return $this->find();

    }

	

}

?>