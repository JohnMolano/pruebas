<?php

	class Mod49GymEncuestaRes extends ActiveRecord

{

	

	public function getTodas(){

        return $this->find();

    }

	

}

?>