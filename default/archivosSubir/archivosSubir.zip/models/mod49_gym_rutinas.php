<?php

	class Mod49GymRutinas extends ActiveRecord
{

	

	public function getTodas(){

        return $this->find();

    }

	

}

?>