<?php

	class Mod49GymPromociones extends ActiveRecord
{

	

	public function getTodas(){

        return $this->find();

    }

	

}

?>