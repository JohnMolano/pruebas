<?php

	class Mod49GymEncuesta extends ActiveRecord

{

	

	public function getTodas(){

        return $this->find();

    }

	

}

?>