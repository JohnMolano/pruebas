<?php

	class Mod49GymGastos extends ActiveRecord

{

	

	public function getTodas(){

        return $this->find();

    }

	

}

?>